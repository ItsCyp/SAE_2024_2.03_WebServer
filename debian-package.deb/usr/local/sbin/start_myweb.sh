#!/bin/bash
# Démarrer le serveur web Java

# Définir le chemin vers le fichier de configuration et le répertoire contenant les classes Java
JAVA_CLASSES_DIR="/usr/local/sbin/myweb"

# Lancer le serveur en arrière-plan
java -cp $JAVA_CLASSES_DIR HttpServer &
# Récupérer le PID du processus Java et l'écrire dans le fichier myweb.pid
echo $! > /var/run/myweb.pid
