#!/bin/bash
# Arrêter le serveur web Java

# Lire le PID du fichier myweb.pid
PID=$(cat /var/run/myweb.pid)
# Tuer le processus
kill $PID
# Supprimer le fichier myweb.pid
rm /var/run/myweb.pid
